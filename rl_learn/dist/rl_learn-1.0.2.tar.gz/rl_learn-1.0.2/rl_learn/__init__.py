"""
rl_learn

A package to accompany the book "Reinforcement Learning: A Python Introduction".

SubPackages
-----------
bandits
  A package for designing and evaluating agents that perform on bandit problems.

... More soon
"""
